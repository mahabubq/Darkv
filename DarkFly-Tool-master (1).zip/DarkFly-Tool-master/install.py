#!/usr/bin/python

"""
Author             : Ms.ambari
contact            : p3ju.kudanil@gmail.com
Github             : https://github.com/Ranginang67
my youtube channel : Ms.ambari

subcribe my youtube Channel to learn ethical Hacking ^_^
"""

import sys
import os.path
import subprocess

ntfile = ['.module', 'lib']

ubuntu = '' + str(open('.module/jalurU.ms').read())
termux = '' + str(open('.module/jalurT.ms').read())
termlb = '' + str(open('.module/ngentot.ms').read())
instal = '' + str(open('.module/IN.ms').read())


def _main_():
    if os.path.isdir('' + ubuntu.strip()):
        if os.getuid() != 0:
            print '[x] Failed: your must be root'
            sys.exit()

        if not os.path.isdir(ntfile[0]):
            print '[x] Failed: no directory module'
            sys.exit()

        if not os.path.isdir(ntfile[1]):
            print '[x] Failed: no directory lib'
            sys.exit()
        else:

            print '' + instal.strip()

            # ==================================================================#

            os.system('python .module/files/' + str(open('.module/A.ms'
                      ).read()))
            os.system('python .module/files/' + str(open('.module/B.ms'
                      ).read()))
            os.system('python .module/files/' + str(open('.module/C.ms'
                      ).read()))
            os.system('python .module/files/' + str(open('.module/D.ms'
                      ).read()))
            os.system('python .module/files/' + str(open('.module/E.ms'
                      ).read()))
            os.system('python .module/files/' + str(open('.module/F.ms'
                      ).read()))
            os.system('python .module/files/' + str(open('.module/G.ms'
                      ).read()))
            os.system('python .module/files/' + str(open('.module/H.ms'
                      ).read()))

            # ==================================================================#

            if os.path.isdir('/usr/bin/lib'):
                os.system('rm -rf /usr/bin/lib')
                os.system('' + str(open('.module/pindahU.ms').read()))
                os.system('' + str(open('.module/PindahU.ms').read()))

            if not os.path.isdir('/usr/bin/lib'):
                os.system('' + str(open('.module/pindahU.ms').read()))
                os.system('' + str(open('.module/PindahU.ms').read()))

            # ==================================================================#

            print '' + str(open('.module/DU.la').read())
            print '' + str(open('.module/Du').read())
            os.system('python .JM.xn')

            # ==================================================================#

    if os.path.isdir('' + termux.strip()):
        if not os.path.isdir('' + termux.strip()):
            sys.exit()

        if not os.path.isdir(ntfile[0]):
            print '[x] Failed: no directory module'
            sys.exit()

        if not os.path.isdir(ntfile[1]):
            print '[x] Failed: no directory lib'
            sys.exit()
        else:

            print '' + instal.strip()

            # ==============================================================#

            os.system('python2 .module/' + str(open('.module/A.ms'
                      ).read()))
            os.system('python2 .module/' + str(open('.module/B.ms'
                      ).read()))
            os.system('python2 .module/' + str(open('.module/C.ms'
                      ).read()))
            os.system('python2 .module/' + str(open('.module/D.ms'
                      ).read()))
            os.system('python2 .module/' + str(open('.module/E.ms'
                      ).read()))
            os.system('python2 .module/' + str(open('.module/F.ms'
                      ).read()))
            os.system('python2 .module/' + str(open('.module/G.ms'
                      ).read()))
            os.system('python2 .module/' + str(open('.module/H.ms'
                      ).read()))

            # ==============================================================#

            if os.path.isdir('' + termlb.strip()):
                os.system('' + str(open('.module/pacar.ms').read()))
                os.system('' + str(open('.module/pindahT.ms').read()))
                os.system('' + str(open('.module/PINDAHT.txt').read()))

            if not os.path.isdir('' + termlb.strip()):
                os.system('' + str(open('.module/pindahT.ms').read()))
                os.system('' + str(open('.module/PINDAHT.txt').read()))

            # ==============================================================#

            print '' + str(open('.module/DU.la').read())
            print '' + str(open('.module/Du').read())
            os.system('python2 .JM.xn && cd')


            # ==============================================================#

if __name__ == '__main__':
    _main_()
